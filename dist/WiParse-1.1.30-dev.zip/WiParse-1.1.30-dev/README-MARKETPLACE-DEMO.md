# WiParse Testing Hub Marketplace Demo (Windows)

## 1. Start marketplace server

```powershell
.\start-marketplace.ps1
```

- URL: http://127.0.0.1:8787
- Publish token: dev-token

Seeded plugins:
- demo-marketplace-plugin@1.0.0
- market-echo@1.0.0
- market-counter@1.1.0
- market-preflight-lab@0.9.0

## 2. Launch WiParse

```powershell
.\start-wiparse.ps1
```

In **集成测试 / Testing Hub**:
1. Switch the left segment to **市场 / Market**
2. If needed, expand **服务器 / Server** and confirm URL `http://127.0.0.1:8787`
3. Refresh → Install a plugin → it opens in **插件** ready to run

Requires Node.js 18+ on PATH.

## CLI smoke

```powershell
$env:WIPARSE_MARKETPLACE_ALLOW_HTTP = "1"
node test-tools\marketplace.mjs catalog --url http://127.0.0.1:8787 --json
node test-tools\marketplace.mjs pull --plugin market-echo --version 1.0.0 `
  --url http://127.0.0.1:8787 --install-dir .\marketplace --json
```
## Automation service (development verification)

Run .\start-automation-service.ps1 before calling the new APIs.
Read docs/AUTOMATION-SERVICE.md and docs/specs/wireless-test/04-software-implementation-review.md.
industrial_approved=false. Complete SW-01..SW-12 and physical system acceptance are pending.
This bundle does not install a Windows Service or provide Dongle capture firmware.
wireless-charge-validation 0.1.1 provides offline configuration/rule replay only; live stimulus and industrial acceptance remain blocked.
MCP 1.1.30 and its dependencies are bundled under mcp/wiparse; Node.js 18+ is still required.
Read docs/releases/1.1.30.md. The Test Report default project includes ScopeSerialDemo (synthetic data only).
