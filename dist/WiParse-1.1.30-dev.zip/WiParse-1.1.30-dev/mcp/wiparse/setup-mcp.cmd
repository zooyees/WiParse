@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-mcp.ps1" -RegisterUser %*
echo.
pause
