# Launch WiParse against this demo folder.
$ErrorActionPreference = "Stop"
$Here = $PSScriptRoot
Set-Location $Here
$env:WIPARSE_MARKETPLACE_ALLOW_HTTP = "1"
$env:WIPARSE_PROJECT_ROOT = $Here
$env:WIPARSE_CONFIG = Join-Path $Here "config.json"
$env:WCM_CONFIG = $env:WIPARSE_CONFIG
$exe = Join-Path $Here "bin\WiParse.exe"
Start-Process -FilePath $exe -WorkingDirectory $Here