$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$env:WIPARSE_SERVICE_ROOT = Join-Path $PSScriptRoot 'automation-data'
& (Join-Path $PSScriptRoot 'bin\WiParse-Service.exe') --data-root $env:WIPARSE_SERVICE_ROOT --port 7879