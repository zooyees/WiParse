# Start local Testing Hub marketplace (seed + listen).
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:TOKEN = "dev-token"
$env:PORT = "8787"
$env:HOST = "127.0.0.1"
$env:DATA_DIR = Join-Path $PWD "services\testing-hub-marketplace\data"
& .\scripts\deploy-marketplace.ps1 @args